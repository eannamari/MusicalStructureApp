package com.example.dell.musicalstructureapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;

import java.util.ArrayList;

public class JamiroquaiActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jamiroquai);

        //These are the songs and their album titles.
        ArrayList<Song> songs = new java.util.ArrayList<Song>();
        songs.add(new Song(getString(R.string.shake_it_on),getString(R.string.automaton) ));
        songs.add(new Song(getString(R.string.automaton),getString(R.string.automaton)));
        songs.add(new Song(getString(R.string.cloud_9),getString(R.string.automaton)));
        songs.add(new Song(getString(R.string.superfresh),getString(R.string.automaton) ));
        songs.add(new Song(getString(R.string.hot_property),getString(R.string.automaton) ));
        songs.add(new Song(getString(R.string.something_about_you),getString(R.string.automaton)));
        songs.add(new Song(getString(R.string.summer_girl),getString(R.string.automaton) ));
        songs.add(new Song(getString(R.string.nights_out_in_the_jungle),getString(R.string.automaton) ));
        songs.add(new Song(getString(R.string.dr_buzz),getString(R.string.automaton)));
        songs.add(new Song(getString(R.string.we_can_do_it),getString(R.string.automaton) ));
        songs.add(new Song(getString(R.string.vitamin),getString(R.string.automaton) ));
        songs.add(new Song(getString(R.string.carla),getString(R.string.automaton)));

        // Create an {@link SongAdapter}, whose data source is a list of {@link Song}s. The
        // adapter knows how to create list items for each item in the list.
        SongAdapter adapter = new SongAdapter(this, songs);

        // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
        // There should be a {@link ListView} with the view ID called list, which is declared in the
        // word_list.xml file.
        android.widget.ListView listView = findViewById(R.id.list);

        // Make the {@link ListView} use the {@link SongAdapter} we created above, so that the
        // {@link ListView} will display list items for each {@link Song} in the list.
        listView.setAdapter(adapter);

        //Set the list item click
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent playerIntent = new Intent(JamiroquaiActivity.this, PlayerActivity.class);

                // Start the new activity
                startActivity(playerIntent);
            }
        });

    }


}