package com.example.dell.musicalstructureapp;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.widget.ArrayAdapter;

import java.util.ArrayList;

public class SongAdapter extends ArrayAdapter<Song> {

    public SongAdapter(Activity context, ArrayList<Song> songs) {
        super(context, 0, songs);
    }


    @Override
    public android.view.View getView(int position, android.view.View convertView, android.view.ViewGroup parent) {

        // Check if the existing view is being reused, otherwise inflate the view
        android.view.View listItemView = convertView;

        if(listItemView == null) {
            listItemView = android.view.LayoutInflater.from(getContext()).inflate(
                    R.layout.list_item, parent, false);
        }

        Song currentSong = getItem(position);

        //This finds and gets the song title
        android.widget.TextView songTitle = listItemView.findViewById(R.id.song_title);
        songTitle.setText(currentSong.getSongTitle());

        //This finds and gets the album title
        android.widget.TextView album = listItemView.findViewById(R.id.album);
        album.setText(currentSong.getAlbumTitle());

        return listItemView;
    }
}
