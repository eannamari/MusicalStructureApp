package com.example.dell.musicalstructureapp;

public class Song {

    private String songTitle;
    private String albumTitle;

    public Song(String songTitle, String albumTitle) {

        this.songTitle = songTitle;
        this.albumTitle = albumTitle;

    }
    public String getAlbumTitle() {
        return albumTitle;
    }

    public String getSongTitle() {
        return songTitle;
    }
}
