package com.example.dell.musicalstructureapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;

import java.util.ArrayList;

public class GeorgeMichaelActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_george_michael);

        //These are the songs and their album titles.
        ArrayList<Song> songs = new java.util.ArrayList<Song>();
        songs.add(new Song(getString(R.string.jesus_to_a_child),getString(R.string.older) ));
        songs.add(new Song(getString(R.string.fastlove),getString(R.string.older) ));
        songs.add(new Song(getString(R.string.older),getString(R.string.older)));
        songs.add(new Song(getString(R.string.spinning_the_wheel),getString(R.string.older)));
        songs.add(new Song(getString(R.string.it_doesnt_really_matter),getString(R.string.older) ));
        songs.add(new Song(getString(R.string.the_strangest_thing),getString(R.string.older) ));
        songs.add(new Song(getString(R.string.to_be_forgiven),getString(R.string.older) ));
        songs.add(new Song(getString(R.string.move_on),getString(R.string.older) ));
        songs.add(new Song(getString(R.string.star_people),getString(R.string.older) ));
        songs.add(new Song(getString(R.string.you_have_been_loved),getString(R.string.older)));
        songs.add(new Song(getString(R.string.free),getString(R.string.older) ));

        // Create an {@link SongAdapter}, whose data source is a list of {@link Song}s. The
        // adapter knows how to create list items for each item in the list.
        SongAdapter adapter = new SongAdapter(this, songs);

        // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
        // There should be a {@link ListView} with the view ID called list, which is declared in the
        // word_list.xml file.
        android.widget.ListView listView = findViewById(R.id.list);

        // Make the {@link ListView} use the {@link SongAdapter} we created above, so that the
        // {@link ListView} will display list items for each {@link Song} in the list.
        listView.setAdapter(adapter);

        //Set the list item click
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent playerIntent = new Intent(GeorgeMichaelActivity.this, PlayerActivity.class);

                // Start the new activity
                startActivity(playerIntent);
            }
        });

    }


}