package com.example.dell.musicalstructureapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;

import java.util.ArrayList;

public class LinkinParkActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_linkin_park);

        //These are the songs and their album titles.
        ArrayList<Song> songs = new java.util.ArrayList<Song>();
        songs.add(new Song(getString(R.string.talking_to_myself), getString(R.string.one_more_light_live) ));
        songs.add(new Song(getString(R.string.burn_it_down), getString(R.string.one_more_light_live) ));
        songs.add(new Song(getString(R.string.battle_symphony), getString(R.string.one_more_light_live) ));
        songs.add(new Song(getString(R.string.new_divide), getString(R.string.one_more_light_live) ));
        songs.add(new Song(getString(R.string.invisible), getString(R.string.one_more_light_live) ));
        songs.add(new Song(getString(R.string.nobody_can_save_me), getString(R.string.one_more_light_live) ));
        songs.add(new Song(getString(R.string.one_more_light), getString(R.string.one_more_light_live) ));
        songs.add(new Song(getString(R.string.crawling), getString(R.string.one_more_light_live) ));
        songs.add(new Song(getString(R.string.leave_out_all_the_rest), getString(R.string.one_more_light_live) ));
        songs.add(new Song(getString(R.string.good_goodbye), getString(R.string.one_more_light_live) ));
        songs.add(new Song(getString(R.string.what_i_have_done), getString(R.string.one_more_light_live) ));
        songs.add(new Song(getString(R.string.in_the_end), getString(R.string.one_more_light_live) ));
        songs.add(new Song(getString(R.string.sharp_edges), getString(R.string.one_more_light_live) ));
        songs.add(new Song(getString(R.string.numb), getString(R.string.one_more_light_live) ));
        songs.add(new Song(getString(R.string.heavy), getString(R.string.one_more_light_live) ));
        songs.add(new Song(getString(R.string.bleed_it_out), getString(R.string.one_more_light_live) ));

        // Create an {@link SongAdapter}, whose data source is a list of {@link Song}s. The
        // adapter knows how to create list items for each item in the list.
        SongAdapter adapter = new SongAdapter(this, songs);

        // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
        // There should be a {@link ListView} with the view ID called list, which is declared in the
        // word_list.xml file.
        android.widget.ListView listView = findViewById(R.id.list);

        // Make the {@link ListView} use the {@link SongAdapter} we created above, so that the
        // {@link ListView} will display list items for each {@link Song} in the list.
        listView.setAdapter(adapter);

        //Set the list item click
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent playerIntent = new Intent(LinkinParkActivity.this, PlayerActivity.class);

                // Start the new activity
                startActivity(playerIntent);
            }
        });

    }


}