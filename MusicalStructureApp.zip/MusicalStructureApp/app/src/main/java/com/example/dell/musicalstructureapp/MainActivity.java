
package com.example.dell.musicalstructureapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find the View that shows the Depeche Mode/Exciter button
        Button dm_button = findViewById(R.id.dm_button);

        // Set a click listener on that View
        dm_button.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the numbers category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link DepecheModeActivity}
                Intent dm_buttonIntent = new Intent(MainActivity.this, DepecheModeActivity.class);

                // Start the new activity
                startActivity(dm_buttonIntent);
            }
        });

        // Find the View that shows the George Michael/Older button
        Button gm_button = findViewById(R.id.gm_button);

        // Set a click listener on that View
        gm_button.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the numbers category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link GeorgeMichaelActivity}
                Intent gm_buttonIntent = new Intent(MainActivity.this, GeorgeMichaelActivity.class);

                // Start the new activity
                startActivity(gm_buttonIntent);
            }
        });

        // Find the View that shows the Jamiroquai/Automaton button
        Button j_button = findViewById(R.id.j_button);

        // Set a click listener on that View
        j_button.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the numbers category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link JamiroquaiActivity}
                Intent j_buttonIntent = new Intent(MainActivity.this, JamiroquaiActivity.class);

                // Start the new activity
                startActivity(j_buttonIntent);
            }
        });

        // Find the View that shows the Linkin Park/One More Light Live button
        Button lp_button = findViewById(R.id.lp_button);

        // Set a click listener on that View
        lp_button.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the numbers category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link LinkinParkActivity}
                Intent lp_buttonIntent = new Intent(MainActivity.this, LinkinParkActivity.class);

                // Start the new activity
                startActivity(lp_buttonIntent);
            }
        });

        // Find the View that shows the Camouflage/Greyscale button
        Button c_button = findViewById(R.id.c_button);

        // Set a click listener on that View
        c_button.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the numbers category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link CamouflageActivity}
                Intent c_buttonIntent = new Intent(MainActivity.this, CamouflageActivity.class);

                // Start the new activity
                startActivity(c_buttonIntent);
            }
        });
    }
}
