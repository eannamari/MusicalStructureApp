package com.example.dell.musicalstructureapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;

public class PlayerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.player);

        // Find the View that shows the play button
        ImageButton play = findViewById(R.id.imageButton);


        // Set a click listener on that View
        play.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the play button is clicked on.
            @Override
            public void onClick(View view) {

                Intent playIntent = new Intent(PlayerActivity.this, MainActivity.class);

                // Start the new activity
                startActivity(playIntent);
            }
        });


    }
}